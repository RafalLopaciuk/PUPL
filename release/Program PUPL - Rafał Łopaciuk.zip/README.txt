PUPL - Program Układający Plany Lekcyjne
Autor: Rafał Łopaciuk

Do poprawnego uruchomienia aplikacji plik "PUPL.exe" musi znajdować się w tej samej lokalizacji co folder "data".

Do samodzielnego wygenerowania planu lekcji niezbędne jest spełnienie dwóch warunków:
1) SAT-sovler wykorzystywany w aplikacji korzysta z dynamicznych bibliotek, dlatego system Windows, na którym uruchomiony został program, musi mieć zainstalowaną paczkę Microsoft Visual C++ 2015-2019 Redistributable x64 (https://aka.ms/vs/16/release/vc_redist.x64.exe). Niepomyślne załadowanie biblioteki będzie widoczne w aplikacji poprzez wyłączony przycisk generowania.
2) Podczas generowania rozwiązania aplikacja tworzy plik tymczasowy, dlatego lokalizacja aplikacji musi umożliwiać stworzenie nowego pliku.
